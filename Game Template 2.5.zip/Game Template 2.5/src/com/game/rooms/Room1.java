package com.game.rooms;

import com.game.objects.Player;
import com.game.objects.Wall;
import com.game.backgroundprocesses.gsm.Room;
import com.game.backgroundprocesses.gsm.RoomManager;
import com.game.backgroundprocesses.main.GamePanel;

import java.awt.*;

public class Room1 extends Room {

    public Room1(RoomManager gsm) {
        super(gsm);
    }

    public void init() { // add your objects here ↓
        objects.add(new Wall(GamePanel.WIDTH/2-5, GamePanel.HEIGHT/2 + 50));
        objects.add(new Wall(GamePanel.WIDTH/2+15, GamePanel.HEIGHT/2 + 50));
        objects.add(new Wall(GamePanel.WIDTH/2+35, GamePanel.HEIGHT/2 + 50));
        objects.add(new Wall(GamePanel.WIDTH/2-25, GamePanel.HEIGHT/2 + 50));
        objects.add(new Player(GamePanel.WIDTH/2, GamePanel.HEIGHT/2));
    }

    public void renderPre(Graphics g) {
        g.drawString("Test", GamePanel.WIDTH/2-10, GamePanel.HEIGHT/2-40);
    }

    public void renderPost(Graphics g) {
        g.drawString("Test", GamePanel.WIDTH/2-10, GamePanel.HEIGHT/2-45);
    }

    public void tick() {

    }

    public void mousePressed() {

    }

    public void mouseReleased() {

    }

    public void keyPressed() {

    }

    public void keyReleased() {

    }
}
