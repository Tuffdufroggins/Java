package com.game.backgroundprocesses.utils;

import java.awt.*;

public class MouseUtils {
    public static boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
        if(mx > x && mx < x + width){
            if(my > y && my < y + height) {
                return true;
            }else {return false; }
        }else{ return false;}
    }

    public void moveMouse(int x, int y) {
        try {
            Robot robot = new Robot();

            robot.mouseMove(x, y);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void clickMouse(int button) {
        try {
            Robot robot = new Robot();

            robot.mousePress(button);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }
}
