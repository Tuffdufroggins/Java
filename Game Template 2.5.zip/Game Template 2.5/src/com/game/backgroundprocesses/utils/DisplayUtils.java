package com.game.backgroundprocesses.utils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class DisplayUtils {

    public static BufferedImage loadImage(String path){
        try {
            return ImageIO.read(new File(path));
        } catch (IOException e) {

            e.printStackTrace();
        }
        return null;
    }

    public static BufferedImage resizeImage(BufferedImage img, int targetWidth, int targetHeight) {
        Image resultingImage = img.getScaledInstance(targetWidth, targetHeight, Image.SCALE_DEFAULT);
        BufferedImage outputImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
        outputImage.getGraphics().drawImage(resultingImage, 0, 0, null);
        return outputImage;
    }

    public static int getStringWidth(Graphics g, String string) {
        return g.getFontMetrics().stringWidth(string);
    }

    public static int getStringWidth(Font font, String string) {
        AffineTransform affinetransform = new AffineTransform();
        FontRenderContext frc = new FontRenderContext(affinetransform,true,true);
        return (int)(font.getStringBounds(string, frc).getWidth());
    }

    public static int getStringHeight(Font font, String string) {
        AffineTransform affinetransform = new AffineTransform();
        FontRenderContext frc = new FontRenderContext(affinetransform,true,true);
        return (int)(font.getStringBounds(string, frc).getHeight());
    }

    public static int getColor(Color color) {
        return getColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static int getColor(int brightness) {
        return getColor(brightness, brightness, brightness, 255);
    }

    public static int getColor(int brightness, int alpha) {
        return getColor(brightness, brightness, brightness, alpha);
    }

    public static int getColor(int red, int green, int blue) {
        return getColor(red, green, blue, 255);
    }

    public static int getColor(int red, int green, int blue, int alpha) {
        int color = 0;
        color |= alpha << 24;
        color |= red << 16;
        color |= green << 8;
        color |= blue;
        return color;
    }

    public static int getRGB(float speed) {
        float hue = (System.currentTimeMillis() % (int)(speed*1000))/(float)(speed*1000);
        return Color.HSBtoRGB(hue, 0.8f, 1);
    }
    public static int getRGB(float speed, long delay) {
        float hue = ((System.currentTimeMillis()-delay) % (int)(speed*1000))/(float)(speed*1000);
        return Color.HSBtoRGB(hue, 0.8f, 1);
    }
    public static int getRGB(float speed, float brightness) {
        float hue = (System.currentTimeMillis() % (int)(speed*1000))/(float)(speed*1000);
        return Color.HSBtoRGB(hue, 0.8f, brightness);
    }
    public static int getRGB(float speed, long delay, float brightness) {
        float hue = ((System.currentTimeMillis()-delay) % (int)(speed*1000))/(float)(speed*1000);
        return Color.HSBtoRGB(hue, 0.8f, brightness);
    }
}
