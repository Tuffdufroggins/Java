package com.game.backgroundprocesses.utils;

import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class TextInput {
    private String text = "";

    private boolean shift = false;
    private boolean active = true;
    private int limit = 256;

    public TextInput() {

    }

    public void keyPress(Font font, int k){
        if(active) {
            if (k != KeyEvent.VK_SPACE && k != KeyEvent.VK_DELETE && k != KeyEvent.VK_BACK_SPACE && k != KeyEvent.VK_SHIFT && k != KeyEvent.VK_CAPS_LOCK && k != KeyEvent.VK_TAB && k != KeyEvent.VK_ENTER && k != KeyEvent.VK_F1 && k != KeyEvent.VK_F2 && k != KeyEvent.VK_F3 && k != KeyEvent.VK_F4 && k != KeyEvent.VK_F5 && k != KeyEvent.VK_F6 && k != KeyEvent.VK_F7 && k != KeyEvent.VK_F8 && k != KeyEvent.VK_F9 && k != KeyEvent.VK_F10 && k != KeyEvent.VK_F11 && k != KeyEvent.VK_F12 && k != KeyEvent.VK_F13 && k != KeyEvent.VK_F14 && k != KeyEvent.VK_F15 && k != KeyEvent.VK_F16 && k != KeyEvent.VK_F17 && k != KeyEvent.VK_F18 && k != KeyEvent.VK_F19 && k != KeyEvent.VK_F20 && k != KeyEvent.VK_F21 && k != KeyEvent.VK_F22 && k != KeyEvent.VK_F23 && k != KeyEvent.VK_F24 && k != KeyEvent.VK_END && k != KeyEvent.VK_ESCAPE && k != KeyEvent.VK_WINDOWS && k != KeyEvent.VK_CONTROL && k != KeyEvent.VK_ALT && k != KeyEvent.VK_CONTEXT_MENU && k != KeyEvent.VK_HOME && k != KeyEvent.VK_PAGE_UP && k != KeyEvent.VK_PAGE_DOWN && k != KeyEvent.VK_RIGHT && k != KeyEvent.VK_UP && k != KeyEvent.VK_DOWN && k != KeyEvent.VK_LEFT && k != KeyEvent.VK_PAUSE && k != KeyEvent.VK_SCROLL_LOCK && k != KeyEvent.VK_INSERT && k != KeyEvent.VK_CLEAR && k != KeyEvent.VK_NUM_LOCK) {
                if (shift) {
                    if(k == KeyEvent.VK_1) {
                        text = text + "!";
                    } else if(k == KeyEvent.VK_2) {
                        text = text + "@";
                    } else if(k == KeyEvent.VK_3) {
                        text = text + "#";
                    } else if(k == KeyEvent.VK_4) {
                        text = text + "$";
                    } else if(k == KeyEvent.VK_5) {
                        text = text + "%";
                    } else if(k == KeyEvent.VK_6) {
                        text = text + "^";
                    } else if(k == KeyEvent.VK_7) {
                        text = text + "&";
                    } else if(k == KeyEvent.VK_8) {
                        text = text + "*";
                    } else if(k == KeyEvent.VK_9) {
                        text = text + "(";
                    } else if(k == KeyEvent.VK_0) {
                        text = text + ")";
                    } else if(k == KeyEvent.VK_BACK_QUOTE) {
                        text = text + "~";
                    } else if(k == KeyEvent.VK_MINUS) {
                        text = text + "_";
                    } else if(k == KeyEvent.VK_EQUALS) {
                        text = text + "+";
                    } else if(k == KeyEvent.VK_BACK_SLASH) {
                        text = text + "|";
                    } else if(k == KeyEvent.VK_OPEN_BRACKET) {
                        text = text + "{";
                    } else if(k == KeyEvent.VK_CLOSE_BRACKET) {
                        text = text + "}";
                    } else if(k == KeyEvent.VK_SEMICOLON) {
                        text = text + ":";
                    } else if(k == KeyEvent.VK_QUOTE) {
                        text = text + "\"";
                    } else if(k == KeyEvent.VK_PERIOD) {
                        text = text + ">";
                    } else if(k == KeyEvent.VK_COMMA) {
                        text = text + "<";
                    } else if(k == KeyEvent.VK_SLASH) {
                        text = text + "?";
                    } else {
                        text = text + KeyEvent.getKeyText(k);
                    }
                } else {
                    if(k == KeyEvent.VK_NUMPAD1) {
                        text = text + "1";
                    } else if(k == KeyEvent.VK_NUMPAD2) {
                        text = text + "2";
                    } else if(k == KeyEvent.VK_NUMPAD3) {
                        text = text + "3";
                    } else if(k == KeyEvent.VK_NUMPAD4) {
                        text = text + "4";
                    } else if(k == KeyEvent.VK_NUMPAD5) {
                        text = text + "5";
                    } else if(k == KeyEvent.VK_NUMPAD6) {
                        text = text + "6";
                    } else if(k == KeyEvent.VK_NUMPAD7) {
                        text = text + "7";
                    } else if(k == KeyEvent.VK_NUMPAD8) {
                        text = text + "8";
                    } else if(k == KeyEvent.VK_NUMPAD9) {
                        text = text + "9";
                    } else if(k == KeyEvent.VK_NUMPAD0) {
                        text = text + "0";
                    } else if(k == KeyEvent.VK_BACK_QUOTE) {
                        text = text + "`";
                    } else if(k == KeyEvent.VK_MINUS) {
                        text = text + "-";
                    } else if(k == KeyEvent.VK_EQUALS) {
                        text = text + "=";
                    } else if(k == KeyEvent.VK_BACK_SLASH) {
                        text = text + "\\";
                    } else if(k == KeyEvent.VK_OPEN_BRACKET) {
                        text = text + "[";
                    } else if(k == KeyEvent.VK_CLOSE_BRACKET) {
                        text = text + "]";
                    } else if(k == KeyEvent.VK_SEMICOLON) {
                        text = text + ";";
                    } else if(k == KeyEvent.VK_QUOTE) {
                        text = text + "'";
                    } else if(k == KeyEvent.VK_PERIOD) {
                        text = text + ".";
                    }
                     else if(k == KeyEvent.VK_COMMA) {
                        text = text + ",";
                    } else if(k == KeyEvent.VK_SLASH) {
                        text = text + "/";
                    } else {
                        text = text + KeyEvent.getKeyText(k).toLowerCase();
                    }
                }
                while(DisplayUtils.getStringWidth(font, text) > limit) {
                    text = text.substring(0, text.length() - 1);
                }
            } else if (k == KeyEvent.VK_SPACE) {
                text = text + " ";
            } else if (k == KeyEvent.VK_SHIFT) {
                shift = true;
            } else if ((k == KeyEvent.VK_BACK_SPACE || k == KeyEvent.VK_DELETE) && text.length() > 0) {
                text = text.substring(0, text.length() - 1);
            }
        }
    }

    public void keyReleased(int k){
        if(k == KeyEvent.VK_SHIFT) {
            shift = false;
        }
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void setText(String text){
        this.text = text;
    }
    public String getText() {
        return this.text;
    }

    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }

    public int getLimit() {
        return limit;
    }
    public void setLimit(Font font, int limit) {
        this.limit = limit;
        while(DisplayUtils.getStringWidth(font, text) > limit) {
            text = text.substring(0, text.length() - 1);
        }
    }
}
