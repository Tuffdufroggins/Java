package com.game.backgroundprocesses.utils;

import java.awt.image.BufferedImage;

public class Animation {
    private BufferedImage[] frames;
    private int framesPerSecond = 30;
    private Timer timer = new Timer();
    private int activeFrame = 0;

    private boolean loop = true;
    private boolean playing = true;

    public Animation(int fps, String... frames) {
        this.frames = new BufferedImage[frames.length];
        for(int i = 0; i < frames.length; i++) {
            this.frames[i] = DisplayUtils.loadImage(frames[i]);
        }
        framesPerSecond = fps;
        activeFrame = 0;
    }

    public void update() {
        if(playing) {
            if (timer.hasTimeElapsed(1000 / framesPerSecond, true)) {
                activeFrame++;
                if (activeFrame >= frames.length) {
                    if (loop) {
                        activeFrame = 0;
                    } else {
                        activeFrame = frames.length - 1;
                    }
                }
            }
        } else {
            timer.reset();
        }
    }

    public BufferedImage getCurrentFrame() {
        return frames[activeFrame];
    }

    public void loop() {
        loop = true;
    }

    public void setLooping(boolean looping) {
        loop = looping;
    }

    public void start() {
        playing = true;
    }

    public void stop() {
        playing = false;
    }

    public void reset() {
        activeFrame = 0;
    }

    public void setFPS(int fps) {
        this.framesPerSecond = fps;
    }

    public void addFrame(BufferedImage img) {
        BufferedImage[] temp = frames.clone();
        frames = new BufferedImage[frames.length+1];
        System.arraycopy(temp, 0, frames, 0, temp.length);
        frames[temp.length] = img;
    }

    public void addFrame(String path) {
        BufferedImage img = DisplayUtils.loadImage(path);
        addFrame(img);
    }
}
