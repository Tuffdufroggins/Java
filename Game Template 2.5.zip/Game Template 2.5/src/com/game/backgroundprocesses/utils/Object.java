package com.game.backgroundprocesses.utils;

import com.game.backgroundprocesses.gsm.Room;
import com.game.backgroundprocesses.gsm.RoomManager;
import com.game.backgroundprocesses.main.GamePanel;
import com.sun.javafx.geom.Vec2d;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class Object {

    public double x, y;
    public int width, height;
    public int hitbox_x, hitbox_y;
    public int hitbox_width, hitbox_height;
    public boolean visible = true;
    public Vec2d gravity = new Vec2d(0, 0);
    public double gravityStrength = 0;
    public int gravityDirection = 180;
    public double vSpeed = 0;
    public double hSpeed = 0;
    public BufferedImage texture = null;
    public Color color = null;
    public boolean useTexture = true;

    public void setup(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        hitbox_x = 0;
        hitbox_y = 0;
        hitbox_width = width;
        hitbox_height = height;
    }

    public void setup(int x, int y, int width, int height, int hitbox_x, int hitbox_y, int hitbox_width, int hitbox_height) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        this.hitbox_x = hitbox_x;
        this.hitbox_y = hitbox_y;
        this.hitbox_width = hitbox_width;
        this.hitbox_height = hitbox_height;
    }

    public void tick() {
        calculateGravity(gravityStrength, gravityDirection + 180);
        step();
        x += hSpeed;
        y += vSpeed;
    }

    public void step() {

    }

    public void draw(Graphics g){
        drawSelf(g);
    }

    public void keyPress(int k){}
    public void keyReleased(int k){}

    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void isClicked(MouseEvent e) {}

    public void handleMouseClicked(MouseEvent e) {
        if(MouseUtils.mouseOver(e.getX(), e.getY(), getScaledX(), getScaledY(), getScaledWidth(), getScaledHeight())) {
            isClicked(e);
        }
        mouseClicked(e);
    }


    public boolean collidingWith(Object object) {
        double temphitbox_x = x + hitbox_x;
        double temphitbox_y = y + hitbox_y;

        if (temphitbox_x > object.x + object.hitbox_x && temphitbox_x < object.x + object.hitbox_x + object.hitbox_width) {
            if (temphitbox_y > object.y + object.hitbox_y && temphitbox_y < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            } else if (temphitbox_y + hitbox_height > object.y + object.hitbox_y && temphitbox_y + hitbox_height < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            }
        } else if (temphitbox_x + hitbox_width > object.x + object.hitbox_x && temphitbox_x + hitbox_width < object.x + object.hitbox_x + object.hitbox_width) {
            if (temphitbox_y > object.y + object.hitbox_y && temphitbox_y < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            } else if (temphitbox_y + hitbox_height > object.y + object.hitbox_y && temphitbox_y + hitbox_height < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            }
        } else if (object.x + object.hitbox_x > temphitbox_x && object.x + object.hitbox_x < temphitbox_x + hitbox_width) {
            if (object.y + object.hitbox_y > temphitbox_y && object.y + object.hitbox_y < temphitbox_y + hitbox_height) {
                return true;
            } else if (object.y + object.hitbox_y + object.hitbox_height > temphitbox_y && object.y + object.hitbox_y + object.hitbox_height < temphitbox_y + hitbox_height) {
                return true;
            }
        } else if (object.x + object.hitbox_x + object.hitbox_width > temphitbox_x && object.x + object.hitbox_x + object.hitbox_width < temphitbox_x + hitbox_width) {
            if (object.y + object.hitbox_y > temphitbox_y && object.y + object.hitbox_y < temphitbox_y + hitbox_height) {
                return true;
            } else if (object.y + object.hitbox_y + object.hitbox_height > temphitbox_y && object.y + object.hitbox_y + object.hitbox_height < temphitbox_y + hitbox_height) {
                return true;
            }
        }
        return false;
    }

    public boolean collidingWith(Object object, double offsetX, double offsetY) {
        double temphitbox_x = x + hitbox_x + offsetX;
        double temphitbox_y = y + hitbox_y + offsetY;

        if (temphitbox_x > object.x + object.hitbox_x && temphitbox_x < object.x + object.hitbox_x + object.hitbox_width) {
            if (temphitbox_y > object.y + object.hitbox_y && temphitbox_y < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            } else if (temphitbox_y + hitbox_height > object.y + object.hitbox_y && temphitbox_y + hitbox_height < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            }
        } else if (temphitbox_x + hitbox_width > object.x + object.hitbox_x && temphitbox_x + hitbox_width < object.x + object.hitbox_x + object.hitbox_width) {
            if (temphitbox_y > object.y + object.hitbox_y && temphitbox_y < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            } else if (temphitbox_y + hitbox_height > object.y + object.hitbox_y && temphitbox_y + hitbox_height < object.y + object.hitbox_y + object.hitbox_height) {
                return true;
            }
        } else if (object.x + object.hitbox_x > temphitbox_x && object.x + object.hitbox_x < temphitbox_x + hitbox_width) {
            if (object.y + object.hitbox_y > temphitbox_y && object.y + object.hitbox_y < temphitbox_y + hitbox_height) {
                return true;
            } else if (object.y + object.hitbox_y + object.hitbox_height > temphitbox_y && object.y + object.hitbox_y + object.hitbox_height < temphitbox_y + hitbox_height) {
                return true;
            }
        } else if (object.x + object.hitbox_x + object.hitbox_width > temphitbox_x && object.x + object.hitbox_x + object.hitbox_width < temphitbox_x + hitbox_width) {
            if (object.y + object.hitbox_y > temphitbox_y && object.y + object.hitbox_y < temphitbox_y + hitbox_height) {
                return true;
            } else if (object.y + object.hitbox_y + object.hitbox_height > temphitbox_y && object.y + object.hitbox_y + object.hitbox_height < temphitbox_y + hitbox_height) {
                return true;
            }
        }
        return false;
    }

    public boolean collidingWith(Class c) {
        for(Object obj : RoomManager.getCurrentRoom().objects) {
            if (c.isInstance(obj)) {
                return collidingWith(obj);
            }
        }
        return false;
    }

    public boolean collidingWith(Class c, double offsetX, double offsetY) {
        for(Object obj : RoomManager.getCurrentRoom().objects) {
            if (c.isInstance(obj)) {
                return collidingWith(obj, offsetX, offsetY);
            }
        }
        return false;
    }

    public void drawSelf(Graphics g) {
        if(visible) {
            if(useTexture) {
                if(texture == null) {
                    if(color != null) {
                        g.setColor(color);
                        g.fillRect(getScaledX(), getScaledY(), getScaledWidth(), getScaledHeight());
                    }
                } else {
                    BufferedImage temp = DisplayUtils.resizeImage(texture, (int)(GamePanel.widthPercent*texture.getWidth()), (int)(GamePanel.heightPercent* texture.getHeight()));
                    g.drawImage(temp, getScaledX(), getScaledY(), temp.getWidth(), temp.getHeight(), null);
                }
            } else {
                if(color != null) {
                    g.setColor(color);
                    g.fillRect(getScaledX(), getScaledY(), getScaledWidth(), getScaledHeight());
                }
            }
        }
    }

    public int getScaledX() {
        return (int)(x*GamePanel.widthPercent);
    }
    public int getScaledY() {
        return (int)(y*GamePanel.heightPercent);
    }
    public int getScaledWidth() {
        return (int)(width*GamePanel.widthPercent);
    }
    public int getScaledHeight() {
        return (int)(height*GamePanel.heightPercent);
    }

    public void moveDir(double distance, int angle) {
        double var1 = distance * Math.sin(Math.toRadians(angle));
        double var2 = distance * Math.cos(Math.toRadians(angle));
        x += var1;
        y += var2;
    }

    public double xDir(double distance, int angle) {
        return distance * -Math.cos(Math.toRadians(angle));
    }

    public double yDir(double distance, int angle) {
        return distance * -Math.sin(Math.toRadians(angle));
    }

    public void calculateGravity(double strength, int direction) {
        gravity.x += xDir(strength, direction);
        gravity.y += yDir(strength, direction);

        // Make a better gravity pls
    }

    public void destroyObject() {
        RoomManager.getCurrentRoom().objects.removeIf(object -> object == this);
    }

    public void destroyObject(Object o) {
        RoomManager.getCurrentRoom().objects.removeIf(object -> object == o);
    }

    public double getDistanceSQ(double x1, double y1, double x2, double y2) {
        double var1 = x2 - x1;
        double var2 = y2 - y1;
        return var1*var1+var2*var2;
    }

    public double getDistance(double x1, double y1, double x2, double y2) {
        double var1 = x2 - x1;
        double var2 = y2 - y1;
        return Math.sqrt(var1*var1+var2*var2);
    }

    public double getDistance(Object o) {
        return getDistance(x, y, o.x, o.y);
    }
    public double getDistance(double x, double y) {
        return getDistance(x, y, this.x, this.y);
    }

    public int getAngle(double x1, double y1, double x2, double y2) {
        double var1 = x2 - x1;
        double var2 = y2 - y1;
        return (int) Math.toDegrees(Math.atan2(var2, var1));
    }
    public int getAngle(Object o) {
        return getAngle(o.x, o.y, x, y);
    }
    public int getAngle(double x, double y) {
        return getAngle(x, y, this.x, this.y);
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getX() {
        return x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getY() {
        return y;
    }
}
