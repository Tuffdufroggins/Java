package com.game.backgroundprocesses.utils;

public class MathUtils {
    // Random Numbers
    public static int randomFrom(int min, int max){
        return((int)(Math.random() * (max+1-min) + min));
    }
    public static double randomFrom(double min, double max){
        return((Math.random() * (max+1-min) + min));
    }
    public static float randomFrom(float min, float max){
        return (float) (Math.random() * (max+1-min) + min);
    }
    public static double randomFrom(double min, double max, float decimal){return(Math.round((Math.random() * (max+1-min) + min)/decimal)*decimal);}
    public static float randomFrom(float min, float max, float decimal){return((float)(Math.round((Math.random() * (max+1-min) + min)/decimal)*decimal));}
    public static short randomFrom(short min, short max){
        return((short)(Math.random() * (max+1-min) + min));
    }
    public static boolean randomBool(){
        return (int) (Math.random() * 2) == 0;
    }

    // Clamp
    public static int clamp(int var, int min, int max) {
        if (var >= min && var <= max) {
            return var;
        } else if (var < min) {
            return min;
        } else {
            return max;
        }
    }

    // Sign
    public static int getSign(float var) {int sign = 0;if(var < 0) {sign = -1;} else if (var > 0) {sign = 1;}return sign;}
    public static int getSign(int var) {int sign = 0;if(var < 0) {sign = -1;} else if (var > 0) {sign = 1;}return sign;}
    public static int getSign(double var) {int sign = 0;if(var < 0) {sign = -1;} else if (var > 0) {sign = 1;}return sign;}

    // Boolean To Integer
    public static int booleanToInt(boolean bool) {int var1 = 0;if(bool) {var1 = 1;}return var1;}
}

