package com.game.backgroundprocesses.main;

import com.game.backgroundprocesses.utils.DisplayUtils;
import com.game.filedata.AudioPlayer;
import com.game.filedata.FileEditor;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class Game {

    private static JFrame window;

    public static void main(String[] args) {
        // Name Your Window Here        ↓
        window = new JFrame("Game Template 2.5");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setLayout(new BorderLayout());
        window.add(new GamePanel(), BorderLayout.CENTER);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);

        // Load Music
        AudioPlayer.load();

        // Play Music on start
        //AudioPlayer.getMusic("music").loop();

        // Load Data
        FileEditor.load();
    }

    public static void setWindowName(String name) {window.setTitle(name);}

    public static void setWindowIcon(String loc) {window.setIconImage(DisplayUtils.loadImage(loc));}

    public static void setResizeable(boolean resizeable) {
        window.setResizable(resizeable);
    }

    public static void setWindowIcon(BufferedImage icon) {
        window.setIconImage(icon);
    }

    public static void center() {
        window.setLocationRelativeTo(null);
    }

    public static void setWindowVisible(boolean visible) {
        window.setVisible(visible);
    }

    public static JFrame getWindow() {
        return window;
    }

}
