package com.game.backgroundprocesses.main;

import com.game.backgroundprocesses.gsm.RoomManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements Runnable, KeyListener, MouseListener {
    private static final long serialVersionID = 1L;

    public static int WIDTH = 700;
    public static int HEIGHT = 500;

    private Thread thread;
    private Boolean running = false;

    public static int fps = 0;

    public static boolean sizeWindow = true;
    public static double widthPercent = 1;
    public static double heightPercent = 1;

    public static RoomManager gsm;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));

        addKeyListener(this);
        addMouseListener(this);
        setFocusable(true);

        start();
    }

    // Ticks
    public synchronized void start() {
        thread = new Thread(this);
        thread.start();
        running = true;
    }

    public synchronized void stop() {
        try{
            thread.join();
            running = false;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void run() {
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        fps = 0;
        gsm = new RoomManager();
        while(running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while(delta >=1) {
                tick();
                delta--;
            }
            if (running) {
                repaint();
            }
            fps++;

            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                fps = 0;
            }
        }
        stop();
    }

    public void tick() {
        if(sizeWindow) {
            calculateSize();
        }
        gsm.tick();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.clearRect(0, 0, (int)getCurrentWidth(), (int)getCurrentHeight());

        if(gsm != null)
            gsm.draw(g);
    }

    public void keyPressed(KeyEvent e) {
        gsm.keyPressed(e.getKeyCode());
    }

    public void keyReleased(KeyEvent e) {
        gsm.keyReleased(e.getKeyCode());
    }

    public void mouseClicked(MouseEvent e) {
        gsm.mouseClicked(e);
    }


    public void mousePressed(MouseEvent e) {
        gsm.mousePressed(e);
    }


    public void mouseReleased(MouseEvent e) {
        gsm.mouseReleased(e);
    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

    public void keyTyped(KeyEvent e) {

    }

    public void calculateSize() {
        heightPercent = getCurrentHeight()/HEIGHT;
        widthPercent = getCurrentWidth()/WIDTH;
    }

    public float getCurrentHeight() {
        return getHeight();
    }

    public float getCurrentWidth() {
        return getWidth();
    }
}
