package com.game.backgroundprocesses.gsm;

import com.game.backgroundprocesses.utils.Object;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public abstract class Room {

    public List<Object> objects = new ArrayList<Object>();

    public Room() {

        init();
    }

    public abstract void init();
    public abstract void render(Graphics g);
    public abstract void renderPre(Graphics g);

    public void tick() {
        for(Object object : objects) {
            object.tick();
        }
    }

    public void draw(Graphics g) {
        renderPre(g);
        for(Object object : objects) {
            object.draw(g);
        }
        render(g);
    }

    public void keyPressed(int k) {
        for(Object object : objects) {
            object.keyPress(k);
        }
    }

    public void keyReleased(int k) {
        for(Object object : objects) {
            object.keyReleased(k);
        }
    }

    public void mouseClicked(MouseEvent e) {
        for(Object object : objects) {
            object.handleMouseClicked(e);
        }
    }

    public void mousePressed(MouseEvent e) {
        for(Object object : objects) {
            object.mousePressed(e);
        }
    }

    public void mouseReleased(MouseEvent e) {
        for(Object object : objects) {
            object.mouseReleased(e);
        }
    }

}
