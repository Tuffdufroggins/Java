package com.game.backgroundprocesses.gsm;

import com.game.rooms.Room1;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.Stack;

public class RoomManager {

    private static Stack<Room> states;

    public RoomManager() {
        states = new Stack<Room>();
        states.push(new Room1(this)); // This is your starting state
    }

    public static Room getCurrentRoom(){
        return states.peek();
    }

    public static void setRoom(Room room) {
        states.push(room);
    }

    public void tick() {
        states.peek().tick();
    }

    public void draw(Graphics g) {
        states.peek().draw(g);
    }

    public void keyPressed(int k) {
        states.peek().keyPressed(k);
    }

    public void keyReleased(int k) {
        states.peek().keyReleased(k);
    }

    public void mouseClicked(MouseEvent e) {
        states.peek().mouseClicked(e);
    }

    public void mousePressed(MouseEvent e) {
        states.peek().mousePressed(e);
    }

    public void mouseReleased(MouseEvent e) {
        states.peek().mouseReleased(e);
    }


}
