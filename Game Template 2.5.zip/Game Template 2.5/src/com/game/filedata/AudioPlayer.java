package com.game.filedata;

import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;

import java.util.HashMap;
import java.util.Map;

public class AudioPlayer {

    // Can Play .wav and .ogg files

    public static Map<String, Sound> soundMap = new HashMap<String, Sound>();
    public static Map<String, Music> musicMap = new HashMap<String, Music>();

    public static void load() {

        // Add sound files to res/audio and initialize them here.
        // Use

        try {
            // Sounds
            // Example:
            soundMap.put("name", new Sound("res/audio/soundname.wav"));

            // Music
            // Example:
            musicMap.put("name", new Music("res/audio/musicname.wav"));
        } catch (SlickException e) {
            //Error will appear if you haven't initialized any sound files or if your paths are wrong

            e.printStackTrace();
        }
    }

    public static Sound getSound(String key) {
        return soundMap.get(key);
    }

    public static Music getMusic(String key) {
        return musicMap.get(key);
    }

    public static void playSound(String ref) {
        try {
            new Sound(ref).play();
        } catch (SlickException e) {
            e.printStackTrace();
        }
    }


}