package com.game.filedata;

import java.io.*;

public class FileEditor {
    public FileEditor() {}

    public static void load(){

        // Do FileEditor.load(); to load data

        try {
            //                                                        File Name ↓
            BufferedReader br = new BufferedReader(new FileReader("res/Save.txt"));

            // Use br.readLine() to get the String from the next line.
            // Parse that String to change it to the data type you need by using:
            // Integer.parseInt(br.readLine()) for ints
            // Float.parseFloat(br.readLine()) for floats
            // Boolean.parseBoolean(br.readLine()) for booleans
            // etc...

            // Example: player.setMoney(Integer.parseInt(br.readLine()));
            // will read the next line and set the players money to it if the next line can be parsed as an integer.

            // There are many other BufferedReader functions that you can use, but I don't know how (or want) to.

            // *can also use FileInputStream or FileOutputStream*

            br.close();


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void save() {

        // Do FileEditor.save(); to save data

        try {
            FileWriter fileWriter = new FileWriter("res/Save.txt");
            PrintWriter printWriter = new PrintWriter(fileWriter);

            //printWriter.println( Data you want to be put on the next line );

            // Example: printWriter.println(player.getMoney());

            printWriter.close();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}
