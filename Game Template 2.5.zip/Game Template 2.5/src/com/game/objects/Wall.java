package com.game.objects;

import com.game.backgroundprocesses.utils.Object;

import java.awt.*;

public class Wall extends Object {

    public Wall(int x, int y) {
        setup(x, y, 20, 20);
        color = new Color(114, 55, 15);
    }

    public void draw(Graphics g){
        drawSelf(g);
    }

}
