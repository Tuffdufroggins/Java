package com.game.objects;

import com.game.backgroundprocesses.utils.MouseUtils;
import com.game.backgroundprocesses.utils.Object;
import com.game.backgroundprocesses.utils.TextInput;

import java.awt.*;
import java.awt.event.MouseEvent;

public class TextBox extends Object {
    TextInput input;
    Font font;
    int offset = 0;

    public TextBox(int x, int y, int width, int height, Font font, int offset) {
        setup(x, y, width, height);
        input = new TextInput();
        this.font = font;
        this.offset = offset;
        input.setLimit(font, width-10);
    }

    public void draw(Graphics g){
        g.setColor(Color.GRAY);
        g.fillRect((int)x, (int)y, width, height);
        g.setColor(Color.BLACK);
        g.fillRect((int)x+4, (int)y+4, width-8, height-8);
        g.setColor(Color.white);
        g.setFont(font);
        g.drawString(input.getText(), (int)x+6, (int)y+height-offset-4);
    }

    public void keyPress(int k){
        input.keyPress(font, k);
    }

    public void keyReleased(int k){
        input.keyReleased(k);
    }

    public void mouseClicked(MouseEvent e) {
        if(MouseUtils.mouseOver(e.getX(), e.getY(), (int)x, (int)y, width, height)) {
            input.setActive(true);
        } else {
            input.setActive(false);
        }
    }
}
