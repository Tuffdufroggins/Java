package com.game.objects;

import com.game.backgroundprocesses.gsm.RoomManager;
import com.game.rooms.Room1;
import com.game.backgroundprocesses.utils.Object;

import java.awt.*;
import java.awt.event.KeyEvent;

public class Player extends Object {

    boolean right = false, left = false, up = false, down = false;

    public Player(int x, int y) {
        setup(x, y, 10, 10);
        color = new Color(0, 200, 200);
    }

    public void step() { // Simple Movement with Collision (That I made in 5 mins, and you shouldn't actually use.)
        if(right) {
            boolean colliding = false;
            for(Object object : RoomManager.getCurrentRoom().objects) {
                if (object instanceof Wall) {
                    if (collidingWith(object, 1, 0)) {
                        colliding = true;
                    }
                }
            }
            if(!colliding) {
                x++;
            }
        }
        if(left) {
            boolean colliding = false;
            for(Object object : RoomManager.getCurrentRoom().objects) {
                if (object instanceof Wall) {
                    if (collidingWith(object, -1, 0)) {
                        colliding = true;
                    }
                }
            }
            if(!colliding) {
                x--;
            }
        }
        if(up) {
            boolean colliding = false;
            for(Object object : RoomManager.getCurrentRoom().objects) {
                if (object instanceof Wall) {
                    if (collidingWith(object, 0, 1)) {
                        colliding = true;
                    }
                }
            }
            if(!colliding) {
                y++;
            }
        }
        if(down) {
            boolean colliding = false;
            for(Object object : RoomManager.getCurrentRoom().objects) {
                if (object instanceof Wall) {
                    if (collidingWith(object, 0, -1)) {
                        colliding = true;
                    }
                }
            }
            if(!colliding) {
                y--;
            }
        }
    }

    public void draw(Graphics g){
        drawSelf(g);
    }

    public void keyPress(int k){
        if(k == KeyEvent.VK_D || k == KeyEvent.VK_RIGHT) {
            right = true;
        }
        if(k == KeyEvent.VK_A || k == KeyEvent.VK_LEFT) {
            left = true;
        }
        if(k == KeyEvent.VK_W || k == KeyEvent.VK_UP) {
            down = true;
        }
        if(k == KeyEvent.VK_S || k == KeyEvent.VK_DOWN) {
            up = true;
        }
    }

    public void keyReleased(int k){
        if(k == KeyEvent.VK_D || k == KeyEvent.VK_RIGHT) {
            right = false;
        }
        if(k == KeyEvent.VK_A || k == KeyEvent.VK_LEFT) {
            left = false;
        }
        if(k == KeyEvent.VK_W || k == KeyEvent.VK_UP) {
            down = false;
        }
        if(k == KeyEvent.VK_S || k == KeyEvent.VK_DOWN) {
            up = false;
        }
    }
}